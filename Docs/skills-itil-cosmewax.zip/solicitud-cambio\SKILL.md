---
name: solicitud-cambio
description: Genera un documento RFC (Request For Change / Solicitud de Cambio) en formato ITIL v4 (Gestión de Cambios), exportado como HTML editable + PDF. Usa como base la plantilla Word ITIL_RFC_Request_For_Change.docx de la carpeta Docs. Redacta de forma funcional y no técnica para que negocio y el comité lo entiendan. Úsalo cuando el usuario diga "solicitud de cambio", "RFC", "request for change", "documento de cambio ITIL", "documenta este cambio", "gestión de cambio", o similar.
---

# Solicitud de Cambio (ITIL v4 — RFC / Change Management)

Genera un documento RFC para solicitar y gestionar un cambio sobre un sistema existente, redactado **de forma funcional y no técnica**, y lo exporta como **HTML editable + PDF**.

## Principios de redacción

- **Funcional, no técnico.** Describe *qué* cambia y *por qué*, no el detalle de implementación. Sin nombres de campos, endpoints, tablas ni código.
- **Conciso.** Frases directas, sin palabrería.
- **Sobre cálculos/fórmulas:** NO detalles las fórmulas. Si el cambio afecta a cálculos, di que usa/mantiene "las mismas fórmulas que ya se usan en el Excel/hoja actual" y que los resultados deben coincidir.
- **Centrado en el riesgo del cambio:** un RFC vive de las secciones de marcha atrás, pruebas y comunicación. No las dejes vacías.
- **Depura el estándar:** si una sección no aplica a este cambio, redúcela o márcala como "No aplica".

## Paso 0 — Delimita ESTRICTAMENTE el alcance de la mejora (lo más importante)

Una mejora/cambio es un **delta** sobre algo que ya existe, **no** el proyecto entero. NUNCA infieras el alcance del proyecto completo ni de `plan.md` (que describe el sistema entero). El RFC debe ceñirse a UNA fuente concreta y acotada. Antes de redactar nada:

1. **Identifica la fuente del cambio**, en este orden de preferencia:
   - **Un plan específico de la mejora** en `Docs/`: un fichero del tipo `plan-<algo>.md` (p. ej. `plan-filtros-busqueda.md`). Es la mejor fuente. Si hay varios, **lista los disponibles y pregunta al usuario cuál** documentar. NO uses el `plan.md` general.
   - **Un ticket / issue** que el usuario indique (Jira, Azure DevOps, etc.): pide el número o el texto.
   - **El cambio realmente hecho en el código**: si la mejora ya está implementada, mira el `git diff`/commits recientes o una entrada de `CHANGELOG` para acotar exactamente qué tocó.
   - **La descripción del propio usuario** en el chat, si no hay documento.
2. **Resume el alcance en una frase y enumera qué entra y qué NO entra**, y **confírmalo con el usuario** antes de generar el documento. Ejemplo: *"Voy a documentar el RFC de «Filtros avanzados de búsqueda». Entra: filtros por cliente/categoría/forma/packaging/fecha. No entra: cascada categoría→subcategoría (queda fuera de esta entrega). ¿Correcto?"*
3. Si el usuario no señala fuente y no hay `plan-*.md` ni diff que acote la mejora, **pregunta**: no inventes el contenido del cambio.

> Regla de oro: si no puedes nombrar la fuente exacta del cambio (un fichero, un ticket o un diff), todavía no tienes alcance — pregunta antes de escribir.

## Pasos

1. **Localiza la plantilla base.** Busca `ITIL_RFC_Request_For_Change.docx` en la carpeta `Docs/` (o `docs/`) del proyecto actual. Es la fuente de verdad de la estructura. Para confirmar las secciones, ábrela: es un `.zip` — extrae `word/document.xml` y lee los títulos. La estructura canónica es:
   1. Identificación del cambio · 2. Clasificación · 3. Descripción · 4. Planificación e implementación · 5. Plan de marcha atrás (rollback) · 6. Plan de pruebas · 7. Comunicación · 8. Evaluación CAB · 9. Revisión posterior (PIR) · 10. Aprobaciones.

2. **Reúne el contexto del cambio confirmado en el Paso 0.** Toda la sección 3 (Descripción), el alcance, los pasos, el rollback y las pruebas salen de esa fuente acotada — no del proyecto entero. Para datos de cabecera que falten (solicitante, sistema afectado, cuándo, entorno), **pregunta al usuario**. Convierte fechas relativas a absolutas.

3. **Genera el HTML.** Copia `assets/template.html` al destino (ver paso 5) y sustituye los marcadores `{{...}}`:
   - `{{EMPRESA}}`, `{{NUM_RFC}}` (p. ej. `RFC-2026-<SLUG>`), `{{TITULO_CAMBIO}}`, `{{AREA_SISTEMA}}`, `{{SOLICITANTE}}`, `{{RESPONSABLE}}`, `{{FECHA}}` (`dd / mm / aaaa`), `{{TICKET}}`, `{{ENTORNO}}` (p. ej. Producción), `{{TIPO_CAMBIO}}` (Normal / Estándar / Urgente), `{{CATEGORIA}}`, `{{PRIORIDAD}}`, `{{RIESGO}}` (Bajo/Medio/Alto).
   - `{{QUE_CAMBIA}}`, `{{MOTIVO}}`, `{{RESULTADO}}`: párrafos funcionales.
   - `{{NOTA_CALCULOS}}`: si el cambio afecta a cálculos, el texto sobre "las mismas fórmulas del Excel". Si NO aplica, elimina por completo el bloque `<div class="nota">{{NOTA_CALCULOS}}</div>`.
   - `{{FECHA_PREVISTA}}`, `{{VENTANA}}` (p. ej. fuera de horario), `{{DURACION}}`, `{{IMPLICADOS}}`.
   - `{{PASOS}}`, `{{ROLLBACK}}`: ítems `<li>...</li>`.
   - `{{PRUEBAS}}`: filas `<tr><td>P-01</td><td>Prueba</td><td>Resultado esperado</td></tr>`.
   - `{{COMUNICACION}}`: filas `<tr><td>A quién</td><td>Qué</td><td>Cuándo</td></tr>`.
   - `{{IMPACTO_NO}}`: qué pasa si el cambio NO se realiza.
   - `{{APROBACIONES}}`: filas `<tr><td>Rol</td><td>Nombre</td><td>&nbsp;</td><td>&nbsp;</td></tr>` (deja decisión/fecha en blanco para firmar).
   - Guarda como `Docs/ITIL_RFC_<TituloCambio>.html`.

4. **Genera el PDF** ejecutando el conversor incluido (encuentra Chrome o Edge automáticamente):
   ```powershell
   powershell -ExecutionPolicy Bypass -File "<ruta-del-skill>/assets/html-to-pdf.ps1" -Html "Docs/ITIL_RFC_<TituloCambio>.html"
   ```
   Genera el `.pdf` junto al `.html`.

5. **Informa al usuario** de las dos rutas (HTML y PDF) como enlaces. Recuérdale que **el HTML es editable**: tras cualquier cambio, basta con volver a ejecutar el conversor del paso 4 para regenerar el PDF.

## Notas

- No modifiques la plantilla Word original; es solo la base de referencia.
- La numeración y los títulos del HTML deben reflejar los de la plantilla Word (ajústalos si el Word cambió).
