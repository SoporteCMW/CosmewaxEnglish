---
name: htmltopdf
description: Convierte un fichero HTML en PDF (mismo nombre, junto al HTML) usando Chrome o Edge en modo headless. Úsalo cuando el usuario edite un HTML y quiera regenerar su PDF, o diga "pasa este html a pdf", "htmltopdf", "convierte a pdf", "regenera el pdf", "exporta el html a pdf". Ideal para los documentos generados por los skills solicitud-nuevo-proyecto y solicitud-cambio tras editarlos a mano.
---

# HTML → PDF

Convierte un fichero `.html` en `.pdf` con el mismo nombre y en la misma carpeta, usando Chrome o Edge en modo headless. Pensado para regenerar el PDF después de editar un HTML a mano (p. ej. los documentos ITIL).

## Pasos

1. **Determina el HTML de entrada:**
   - Si el usuario indica una ruta, úsala.
   - Si no, usa el `.html` que el usuario tenga abierto en el editor (contexto del IDE).
   - Si hay varios candidatos o ninguno claro, **pregunta cuál** convertir.

2. **Genera el PDF** ejecutando el conversor incluido (detecta Chrome o Edge automáticamente):
   ```powershell
   powershell -ExecutionPolicy Bypass -File "<ruta-de-este-skill>/assets/html-to-pdf.ps1" -Html "<ruta-del-html>"
   ```
   - El PDF se crea junto al HTML, con el mismo nombre (`documento.html` → `documento.pdf`).
   - Para forzar otra ruta de salida, añade `-Pdf "<ruta-de-salida.pdf>"`.

3. **Informa al usuario** de la ruta del PDF generado como enlace, y confirma que se regeneró correctamente (el script avisa del tamaño del fichero).

## Notas

- Requiere **Google Chrome** o **Microsoft Edge** instalados; el conversor los busca solo.
- No modifica el HTML: solo lo renderiza a PDF. Para cambiar el contenido o el estilo, edita el `.html` y vuelve a ejecutar este skill.
- El tamaño/márgenes de página (A4) y los estilos salen del propio HTML (su bloque `<style>` y `@page`).
