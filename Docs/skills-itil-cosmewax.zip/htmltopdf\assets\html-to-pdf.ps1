<#
  html-to-pdf.ps1 — Convierte un HTML en PDF usando Chrome o Edge en modo headless.
  Uso:
    powershell -ExecutionPolicy Bypass -File html-to-pdf.ps1 -Html "ruta\fichero.html" [-Pdf "ruta\salida.pdf"]
  Si no se indica -Pdf, genera el PDF junto al HTML con el mismo nombre.
#>
param(
  [Parameter(Mandatory = $true)][string]$Html,
  [string]$Pdf
)

$ErrorActionPreference = 'Stop'

$Html = (Resolve-Path $Html).Path
if (-not $Pdf) { $Pdf = [System.IO.Path]::ChangeExtension($Html, '.pdf') }

# Buscar un navegador basado en Chromium (Chrome o Edge), 64 y 32 bits
$candidatos = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)
$browser = $candidatos | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $browser) {
  Write-Error "No se encontro Chrome ni Edge para generar el PDF."
  exit 1
}

# Borrar PDF previo para detectar fallos de forma fiable
if (Test-Path $Pdf) { Remove-Item $Pdf -Force }

$uri = "file:///" + ($Html -replace '\\', '/')
& $browser --headless --disable-gpu --no-pdf-header-footer "--print-to-pdf=$Pdf" $uri 2>$null | Out-Null

# Chrome escribe el PDF de forma asincrona; esperar a que aparezca
$intentos = 0
while (-not (Test-Path $Pdf) -and $intentos -lt 20) {
  Start-Sleep -Milliseconds 300
  $intentos++
}

if (Test-Path $Pdf) {
  $kb = [math]::Round((Get-Item $Pdf).Length / 1KB)
  Write-Host "OK  PDF generado: $Pdf  ($kb KB)"
} else {
  Write-Error "No se pudo generar el PDF con $browser"
  exit 1
}
