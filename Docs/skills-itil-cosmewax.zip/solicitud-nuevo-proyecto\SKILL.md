---
name: solicitud-nuevo-proyecto
description: Genera un documento de Solicitud de Nuevo Proyecto / Evolutivo en formato ITIL v4 (Gestión de la Demanda), exportado como HTML editable + PDF. Usa como base la plantilla Word ITIL_Relevamiento_Nuevo_Proyecto.docx de la carpeta Docs. Redacta de forma funcional y no técnica para que negocio lo entienda. Úsalo cuando el usuario diga "solicitud de nuevo proyecto", "relevamiento", "documento ITIL de proyecto", "formulario de demanda", "documenta este requerimiento para negocio", o similar.
---

# Solicitud de Nuevo Proyecto (ITIL v4 — Relevamiento)

Genera un documento de relevamiento de un nuevo proyecto/evolutivo, redactado **de forma funcional y no técnica** (lo lee negocio), y lo exporta como **HTML editable + PDF**.

## Principios de redacción

- **Funcional, no técnico.** Describe *qué* hace y *para qué sirve*, no *cómo* está implementado. Sin nombres de campos, endpoints, tablas ni fragmentos de código.
- **Conciso.** Frases directas, sin palabrería. Mejor una frase clara que un párrafo.
- **Sobre cálculos/fórmulas:** NO detalles las fórmulas. Si el proyecto reproduce cálculos existentes, di que usa "las mismas fórmulas que ya se usan en el Excel/hoja actual" y que los resultados deben coincidir.
- **Depura el estándar:** si una sección no aporta a este proyecto, omítela o redúcela. Estamos creando un estándar reutilizable, no rellenar por rellenar.

## Pasos

1. **Localiza la plantilla base.** Busca `ITIL_Relevamiento_Nuevo_Proyecto.docx` en la carpeta `Docs/` (o `docs/`) del proyecto actual. Es la fuente de verdad de la estructura. Si quieres confirmar las secciones, ábrela: es un `.zip` — extrae `word/document.xml` y lee los títulos. La estructura canónica es:
   1. Identificación de la solicitud · 2. Clasificación · 3. Descripción funcional (situación actual / deseada / beneficio) · 4. Alcance (in/out) · 5. Requerimientos funcionales · 6. Dependencias e integraciones · 7. Fases · 8. Riesgos · 9. Aprobaciones · 10. Historial.

2. **Reúne el contexto.** Lee `plan.md`, `README.md` u otra documentación del proyecto. Si faltan datos clave (nombre del proyecto, área y persona solicitante, problema actual, objetivo, beneficio), **pregunta al usuario** brevemente antes de redactar. Convierte fechas relativas a absolutas.

3. **Genera el HTML.** Copia `assets/template.html` al destino (ver paso 5) y sustituye los marcadores `{{...}}`:
   - `{{EMPRESA}}`, `{{NUM_SOLICITUD}}` (p. ej. `REQ-2026-<SLUG>`), `{{NOMBRE_PROYECTO}}`, `{{AREA}}`, `{{SOLICITANTE}}`, `{{FECHA}}` (formato `dd / mm / aaaa`), `{{SISTEMAS}}`, `{{TIPO}}`, `{{IMPACTO}}`, `{{NATURALEZA}}`.
   - `{{AS_IS}}`, `{{TO_BE}}`: párrafos funcionales (situación actual / deseada).
   - `{{NOTA_CALCULOS}}`: si hay cálculos, el texto sobre "las mismas fórmulas del Excel". Si NO hay cálculos, elimina por completo el bloque `<div class="nota">{{NOTA_CALCULOS}}</div>`.
   - `{{BENEFICIOS}}`, `{{IN_SCOPE}}`, `{{OUT_SCOPE}}`: ítems `<li>...</li>`.
   - `{{REQUERIMIENTOS}}`: filas `<tr><td>RF-01</td><td><strong>Título.</strong> Descripción.</td><td><span class="tag">Imprescindible</span></td></tr>`. Usa `tag` (verde) = Imprescindible, `tag gris` = Deseable, `tag azul` = Recomendable.
   - `{{NO_FUNCIONALES}}`: filas `<tr><td class="k">Aspecto</td><td>...</td></tr>` (facilidad de uso, rapidez, fiabilidad, seguridad…).
   - `{{DEPENDENCIAS}}`: filas `<tr><td><strong>Sistema</strong></td><td>Para qué</td><td><span class="tag">Alta</span></td></tr>`.
   - `{{FASES}}`: filas `<tr><td>1</td><td><strong>Título.</strong> Entregable.</td></tr>`.
   - `{{RIESGOS}}`: filas `<tr><td>R-01</td><td>Riesgo</td><td>Mitigación</td></tr>`.
   - `{{APROBACIONES}}`: filas `<tr><td>Rol</td><td>Nombre</td><td>&nbsp;</td><td>&nbsp;</td></tr>` (deja decisión/fecha en blanco para firmar).
   - Guarda como `Docs/ITIL_Relevamiento_<NombreProyecto>.html`.

4. **Genera el PDF** ejecutando el conversor incluido (encuentra Chrome o Edge automáticamente):
   ```powershell
   powershell -ExecutionPolicy Bypass -File "<ruta-del-skill>/assets/html-to-pdf.ps1" -Html "Docs/ITIL_Relevamiento_<NombreProyecto>.html"
   ```
   Genera el `.pdf` junto al `.html`.

5. **Informa al usuario** de las dos rutas (HTML y PDF) como enlaces. Recuérdale que **el HTML es editable**: tras cualquier cambio, basta con volver a ejecutar el conversor del paso 4 para regenerar el PDF.

## Notas

- No modifiques la plantilla Word original; es solo la base de referencia.
- La numeración y los títulos del HTML deben reflejar los de la plantilla Word (ajústalos si el Word cambió).
