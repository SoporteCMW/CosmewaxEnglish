# Skills ITIL — Documentación funcional (Cosmewax IT)

Dos skills para Claude Code que generan documentos ITIL v4 **funcionales y no técnicos**,
exportados como **HTML editable + PDF**, usando como base las plantillas Word de la carpeta `Docs/`.

| Skill | Para qué | Plantilla base (en `Docs/`) |
|-------|----------|------------------------------|
| `solicitud-nuevo-proyecto` | Solicitud de **nuevo proyecto / evolutivo** (Gestión de la Demanda) | `ITIL_Relevamiento_Nuevo_Proyecto.docx` |
| `solicitud-cambio` | **RFC / Solicitud de cambio** sobre algo existente (Gestión de Cambios) | `ITIL_RFC_Request_For_Change.docx` |
| `htmltopdf` | **Regenera el PDF** a partir de un HTML editado (Chrome/Edge headless) | — |

## Instalación (global, por equipo)

Copia las dos carpetas de skill dentro de la carpeta de skills de Claude del usuario:

- **Windows:** `C:\Users\<usuario>\.claude\skills\`
- **macOS / Linux:** `~/.claude/skills/`

Es decir, que queden así:

```
~/.claude/skills/
├── solicitud-nuevo-proyecto/
│   ├── SKILL.md
│   └── assets/ (template.html, html-to-pdf.ps1)
└── solicitud-cambio/
    ├── SKILL.md
    └── assets/ (template.html, html-to-pdf.ps1)
```

No requiere reiniciar nada: Claude detecta los skills en la siguiente sesión.

## Cómo se usan

Dentro de un proyecto que tenga la plantilla Word en su carpeta `Docs/`, pídeselo a Claude:

- *"Genera la solicitud de nuevo proyecto de esto, para Marisa de Planning, en plan funcional."*
- *"Documenta el RFC de la mejora de filtros de búsqueda."*

El skill:
1. Busca la plantilla Word en `Docs/` y respeta su estructura de secciones.
2. Redacta de forma funcional (sin tecnicismos; no detalla fórmulas, solo dice que son las del Excel).
3. Genera `Docs/<documento>.html` (editable) y su `.pdf`.

**Para regenerar el PDF tras editar el HTML a mano**, pídeselo a Claude con el skill `htmltopdf`:

- *"Pasa este html a pdf"* (con el HTML abierto en el editor), o *"regenera el pdf de Docs/mi-doc.html"*.

O directamente por línea de comandos:

```powershell
powershell -ExecutionPolicy Bypass -File "<carpeta-del-skill>\assets\html-to-pdf.ps1" -Html "Docs\<documento>.html"
```

## Requisitos

- **Google Chrome** o **Microsoft Edge** instalados (se usan en modo headless para crear el PDF).
  El conversor los detecta automáticamente.

## Diferencia clave entre los dos skills

- **Nuevo proyecto**: parte del `plan.md` / contexto general del proyecto.
- **Cambio (RFC)**: una mejora es un *delta*. El skill **no** infiere el alcance del proyecto entero;
  se ancla a una fuente concreta (un `plan-<mejora>.md` en `Docs/`, un ticket, o un `git diff`) y
  **confirma contigo qué entra y qué no** antes de redactar.
